class Constants {
  static const String emailPromptTemplate = "Write an email according to the following prompt given by the user: ";
  static const String shortEmailPrompt = "Keep it short and friendly.";
  static const String longEmailPrompt = "Include more details and context.";
}